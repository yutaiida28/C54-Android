package com.eric.labonte.appannexe1b

data class Planete (  var nom:String,  var nbSatellites:Int) {

    // constructeur primaire, on ne peut pas faire d'autres initialisations, seulement y passer des paramètres. le constructeur n'a pas
    //de code



}
