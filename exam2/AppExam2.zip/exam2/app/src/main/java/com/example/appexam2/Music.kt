package com.example.appexam2

data class Music(
    val nom: String,
    val date_sortie: String,
    val nb_chansons: Int,
    val type: String
)
