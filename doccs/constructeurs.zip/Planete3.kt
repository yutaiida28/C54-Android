package com.eric.labonte.appannexe1b

class Planete3 (var nom:String, var nbSatellites:Int){
    init{
        nom = nom.lowercase()
    }
}