package com.eric.labonte.appannexe1b

data class Planete2 (private var nom:String, private var nbSatellites:Int){

    // si on veut , utiliser un bloc init
    private var nbHabitants:Long = 0
    init {
        if ( nom == "Terre")
            nbHabitants = 8_000_000_000;

    }
    //constructeur secondaire : doit se baser sur le primaire
    constructor( nom:String, nbSatellites:Int, nbHabitants:Long) :this(nom,nbSatellites){
        this.nbHabitants = nbHabitants;

    }
   // facultatif, si se distingue d,un accesseur de base ou si modificateur d acces
    fun getNom():String{
        return nom;
    }

    fun getNbSatellites():Int{
        return nbSatellites;
    }

    fun getNbHabitants():Long{
        return nbHabitants;
    }

    fun setNbSatellites(nbSatellites:Int){
        this.nbSatellites = nbSatellites;
    }



    // mot clé constructor pas necessaire, à moins que le constructeur aie un modificateur d'acces
//    class Planete protected constructor( private var nom:String, private var nbSatellites:Int){




}